console.log("[SOMA sitemap] Version 2.0.1");

/*
 * SOMA Casa — Sitemap del Website Connector «SOMA Casa Web» (Data 360)
 * --------------------------------------------------------------------
 * Este sitemap vive en el conector de Data Cloud y lo sirve el CDN junto con el
 * Salesforce Interactions SDK. En la web solo hay que poner, en el <head> de
 * index.html, producto.html y login.html:
 *   <script src="https://cdn.c360a.salesforce.com/beacon/c360a/<id-conector>/scripts/c360a.min.js"></script>
 *
 * Eventos (todos existen como developerName en el esquema estándar del conector):
 *   - Vista de página ................ userEngagement     (View Home / View Login / View Page)
 *   - Vista de detalle de producto ... catalog            (ViewCatalogObject)
 *   - Añadir a la bolsa .............. cart + cartItem    (AddToCart)
 *   - Compra («Finalizar compra») .... order + orderItem  (Purchase)
 *   - Login («Entrar a mi espacio») .. contactPointEmail + identity + partyIdentification
 * Personalización (Salesforce Personalization): SOMA_Home_Hero y SOMA_PDP_Recs.
 *
 * Clave de producto: el catálogo de Data 360 usa el SKU FUR1..FUR6 (igual que
 * Productos.csv y Pedidos.csv). La web usa slugs; aquí se traducen.
 */

SalesforceInteractions.setLoggingLevel(5);

(function () {
  "use strict";

  var SI = window.SalesforceInteractions;
  var CURRENCY = "EUR";
  var SKU_BY_SLUG = {
    "sillon-alba": "FUR1", "lampara-duna": "FUR2", "jarron-tierra": "FUR3",
    "mesa-noma": "FUR4", "cojin-brisa": "FUR5", "espejo-arco": "FUR6"
  };
  var SLUG_BY_SKU = {};
  Object.keys(SKU_BY_SLUG).forEach(function (s) { SLUG_BY_SKU[SKU_BY_SLUG[s]] = s; });
  var P13N_POINTS = { home: ["SOMA_Home_Hero", "SOMA_PDP_Recs"], product: ["SOMA_PDP_Recs"] };

  /* ------------------------------ utilidades ------------------------------ */
  function products() { return window.SOMA_PRODUCTS || []; }
  function bySlug(slug) { return products().find(function (p) { return p.id === slug; }); }
  function bySku(id) { return bySlug(SLUG_BY_SKU[id] || id); }
  function sku(slug) { return SKU_BY_SLUG[slug] || slug; }
  function page() { return (document.body && document.body.dataset.page) || "default"; }
  function currentProduct() { return bySlug(new URLSearchParams(window.location.search).get("id")); }
  function engagement(name) { return { name: name, eventType: "userEngagement" }; }
  function send(event) {
    try { return SI.sendEvent(event); }
    catch (error) { console.warn("[SOMA sitemap] sendEvent", error); }
  }
  // La tienda pinta su contenido con scripts «defer»: esperamos al DOM completo
  // para que los listeners del sitemap encuentren los botones.
  function domReady() {
    return new Promise(function (resolve) {
      if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", resolve, { once: true });
      else resolve();
    });
  }
  function bag() {
    try { return (JSON.parse(sessionStorage.getItem("soma.demo.v1") || "{}").bag) || {}; }
    catch (error) { return {}; }
  }

  /* ------------------------------ identidad ------------------------------ */
  function identify(email) {
    if (!email) return;
    // 1) Punto de contacto (clave de unificación por email).
    send({ user: { attributes: { eventType: "contactPointEmail", email: email } } });
    // 2) Identidad del visitante, asociada a la interacción de login.
    send({
      interaction: { name: "Login", eventType: "userEngagement" },
      user: { attributes: { eventType: "identity", email: email, isAnonymous: "0" } }
    });
    // 3) Identificador de negocio (login).
    send({ user: { attributes: { eventType: "partyIdentification", userId: email, IDName: "SOMA Login", IDType: "Email" } } });
    console.log("[SOMA sitemap] Visitante identificado:", email);
  }

  /* -------------------------------- compra -------------------------------- */
  // La tienda de ejemplo no tiene checkout: el sitemap añade «Finalizar compra» en la bolsa.
  function buildOrder() {
    var items = bag();
    var lines = products().filter(function (p) { return Number(items[p.id]) > 0; }).map(function (p) {
      return {
        catalogObjectType: "Product", catalogObjectId: sku(p.id), price: p.price,
        quantity: Math.max(1, Math.floor(Number(items[p.id]))), currency: CURRENCY
      };
    });
    return {
      id: "SOMA-" + Date.now(), currency: CURRENCY, lineItems: lines,
      totalValue: lines.reduce(function (t, l) { return t + l.price * l.quantity; }, 0)
    };
  }
  function checkout() {
    var order = buildOrder();
    if (!order.lineItems.length) return;
    send({ interaction: { name: SI.OrderInteractionName.Purchase, order: order } });
    try {
      var state = JSON.parse(sessionStorage.getItem("soma.demo.v1") || "{}");
      state.bag = {};
      sessionStorage.setItem("soma.demo.v1", JSON.stringify(state));
    } catch (error) { /* modo privado */ }
    var count = document.getElementById("bag-count");
    if (count) count.textContent = "0";
    var content = document.getElementById("bag-content");
    if (content) content.innerHTML = '<p class="empty-state">¡Gracias! Pedido ' + order.id + " confirmado (" + order.totalValue + " €).</p>";
    console.log("[SOMA sitemap] Compra enviada:", order.id);
  }
  function ensureCheckoutButton() {
    var content = document.getElementById("bag-content");
    if (!content || !content.querySelector(".bag-list") || content.querySelector("#checkout-button")) return;
    var b = document.createElement("button");
    b.id = "checkout-button"; b.type = "button"; b.className = "button"; b.textContent = "Finalizar compra";
    b.addEventListener("click", checkout);
    content.appendChild(b);
  }
  function watchBag() {
    var content = document.getElementById("bag-content");
    if (!content) return;
    ensureCheckoutButton();
    new MutationObserver(ensureCheckoutButton).observe(content, { childList: true });
  }

  /* ---------------------------- personalización ---------------------------- */
  function styles() {
    if (document.getElementById("p13n-styles")) return;
    var st = document.createElement("style"); st.id = "p13n-styles";
    st.textContent = ".p13n-zone{margin:48px auto;padding:32px 0;border-top:1px solid rgba(0,0,0,.08)}" +
      ".p13n-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:24px;margin-top:16px}" +
      ".p13n-item{display:block;text-decoration:none;color:inherit}.p13n-item img{width:100%;height:auto;border-radius:12px}" +
      ".p13n-hero{display:grid;grid-template-columns:1fr 220px;gap:8px 32px;align-items:center}" +
      ".p13n-hero img{grid-row:1/span 3;grid-column:2;width:220px;height:auto;border-radius:16px}.p13n-hero .button{justify-self:start}";
    document.head.appendChild(st);
  }
  function zone(id, after) {
    styles();
    var el = document.getElementById(id); if (el) return el;
    var ref = document.querySelector(after); if (!ref) return null;
    el = document.createElement("section"); el.id = id; el.className = "wrap p13n-zone";
    ref.insertAdjacentElement("afterend", el); return el;
  }
  function txt(tag, value, cls) { var e = document.createElement(tag); if (cls) e.className = cls; e.textContent = value || ""; return e; }
  function trackClick(el, entry, contentId) {
    el.addEventListener("click", function () {
      send({ interaction: engagement("personalization-click"),
        personalization: { id: entry.personalizationId, contentId: contentId || entry.personalizationId } });
    });
  }
  function renderRecs(entry) {
    var el = page() === "product" ? zone("p13n-pdp-recs", ".product-layout") : zone("p13n-pdp-recs", "#coleccion");
    if (!el) return;
    el.innerHTML = "";
    el.appendChild(txt("h2", (entry.attributes || {}).IntroductionText || "Seleccionado para ti"));
    var grid = document.createElement("div"); grid.className = "product-grid p13n-grid";
    (entry.data || []).slice(0, 4).forEach(function (item) {
      var p = bySku(item.ssot__Id__c || item.id); if (!p) return;
      var a = document.createElement("a"); a.className = "p13n-item"; a.href = "producto.html?id=" + encodeURIComponent(p.id);
      var img = document.createElement("img"); img.src = p.images[0]; img.alt = p.name; a.appendChild(img);
      a.appendChild(txt("h3", p.name)); a.appendChild(txt("p", p.category + " · " + p.price + " €"));
      trackClick(a, entry, item.personalizationContentId); grid.appendChild(a);
    });
    el.appendChild(grid);
  }
  function renderHero(entry) {
    var el = zone("p13n-home-hero", ".hero"); if (!el) return;
    var item = (entry.data || [])[0], p = item ? bySku(item.ssot__Id__c || item.id) : null, at = entry.attributes || {};
    el.innerHTML = ""; el.className = "wrap p13n-zone p13n-hero";
    el.appendChild(txt("p", at.IntroductionText || "Inspirado en tu estilo", "eyebrow"));
    el.appendChild(txt("h2", p ? p.name + " · " + p.category : "Descubre la colección"));
    if (p) {
      var img = document.createElement("img"); img.src = p.images[0]; img.alt = p.name; el.appendChild(img);
      var cta = document.createElement("a"); cta.className = "button"; cta.href = "producto.html?id=" + encodeURIComponent(p.id);
      cta.textContent = "Descúbrela"; trackClick(cta, entry, item.personalizationContentId); el.appendChild(cta);
    }
  }
  function personalize() {
    var points = P13N_POINTS[page()] || [];
    if (!points.length || !SI.Personalization || typeof SI.Personalization.fetch !== "function") return;
    SI.Personalization.fetch(points).then(function (res) {
      ((res && res.personalizations) || []).forEach(function (entry) {
        if (entry.personalizationPointName === "SOMA_Home_Hero") renderHero(entry);
        else if (entry.personalizationPointName === "SOMA_PDP_Recs") renderRecs(entry);
        else return;
        send({ interaction: engagement("personalization-view"),
          personalization: { id: entry.personalizationId, contentId: entry.personalizationId } });
      });
      console.log("[SOMA sitemap] Personalización recibida:", (res && res.personalizations || []).length, "punto(s)");
    }).catch(function (error) { console.warn("[SOMA sitemap] Personalization.fetch", error); });
  }

  /* -------------------------------- sitemap -------------------------------- */
  function buildSitemap() {
    var product = currentProduct();
    var listener = SI.listener;

    var global = {
      locale: "es_ES",
      listeners: [
        listener("click", "[data-track-login]", function () { send({ interaction: engagement("Open Login") }); }),
        listener("click", "[data-filter]", function (e) {
          var f = e.target.closest("[data-filter]");
          if (f) send({ interaction: engagement("Filter " + f.dataset.filter) });
        })
      ]
    };

    var pageTypes = [
      {
        name: "home",
        isMatch: function () { return page() === "home"; },
        interaction: engagement("View Home")
      },
      {
        name: "product_detail",
        isMatch: function () { return page() === "product" && Boolean(product); },
        interaction: product ? {
          // Esta constante hace que el SDK genere eventType «catalog».
          name: SI.CatalogObjectInteractionName.ViewCatalogObject,
          catalogObject: {
            type: "Product",
            id: sku(product.id),
            attributes: { name: product.name, price: product.price, category: product.category }
          }
        } : undefined,
        listeners: [
          listener("click", "#add-to-bag", function () {
            var qty = Number((document.getElementById("quantity-value") || {}).textContent) || 1;
            send({ interaction: { name: SI.CartInteractionName.AddToCart, lineItem: {
              catalogObjectType: "Product", catalogObjectId: sku(product.id),
              price: product.price, quantity: qty, currency: CURRENCY } } });
          })
        ]
      },
      {
        name: "login",
        isMatch: function () { return page() === "login"; },
        interaction: engagement("View Login"),
        listeners: [
          // «Entrar a mi espacio»: solo se lee el email, nunca la contraseña.
          listener("click", "#login-form button[type=submit]", function () {
            var input = document.getElementById("email");
            if (input && input.checkValidity()) identify(input.value.trim().toLowerCase());
          })
        ]
      }
    ];

    var pageTypeDefault = { name: "default", interaction: engagement("View Page") };

    return { global: global, pageTypes: pageTypes, pageTypeDefault: pageTypeDefault };
  }

  /* ----------------------------- arranque ----------------------------- */
  function consentList() {
    return [{ provider: "SOMA Casa", purpose: SI.ConsentPurpose.Tracking, status: SI.ConsentStatus.OptIn }];
  }

  SI.init({
    cookieDomain: window.location.hostname,
    // Demo: consentimiento de medición aceptado al cargar (formato lista del SDK de Data 360).
    consents: new Promise(function (resolve) { resolve(consentList()); }),
    dataspace: "default"
  }).then(function () {
    SI.updateConsents(consentList());
    return domReady();
  }).then(function () {
    SI.initSitemap(buildSitemap());
    watchBag();
    personalize();
    console.log("[SOMA sitemap] Inicializado para:", window.location.href, "· visitante", SI.getAnonymousId());
  }).catch(function (error) {
    console.error("[SOMA sitemap] Error durante la inicialización", error);
  });
}());
