"""Prueba optativa de calificadores; --apply requiere autorización explícita del usuario.
Sin --apply solo valida la propuesta local. Nunca modifica la org de origen.
"""
import argparse,hashlib,json,os,signal,subprocess,time,urllib.parse
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EXPECTED_ORG='00Dg800000MuBLvEAN'
TARGET='SOMA_Piloto'
ENV=dict(os.environ,NODE_USE_SYSTEM_CA='1',SF_DISABLE_LOG_FILE='true',SF_DISABLE_TELEMETRY='true',SF_AUTOUPDATE_DISABLE='true')
ENTRIES=[('SOMA_Perfil_RT','2Lwg80000016Lik','SOMA_Perfil_RT_QA_20261008'),('SOMA_Productos_RT','2Lwg80000016Lil','SOMA_Productos_RT_QA_20261008')]
BASE='/services/data/v67.0/'

def call(name,path,method='GET',body=None):
 dest=ROOT/(name+'-response.json');dest.unlink(missing_ok=True)
 args=['sf','api','request','rest',BASE+path,'--target-org',TARGET,'--method',method,'--stream-to-file',str(dest)]
 if body is not None:
  request=ROOT/(name+'-request.json');request.write_text(json.dumps(body,ensure_ascii=False));args+=['--body','@'+str(request),'--header','Content-Type:application/json']
 result=subprocess.run(args,env=ENV,text=True,capture_output=True,timeout=120)
 if result.returncode:raise RuntimeError(name+': la CLI no completó la petición (consultar respuesta guardada).')
 data=json.loads(dest.read_text()) if dest.exists() and dest.stat().st_size else None
 if isinstance(data,list) and data and isinstance(data[0],dict) and 'errorCode' in data[0]:raise RuntimeError(name+': '+str(data))
 return data

def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def walk(x):
 yield x
 for c in x.get('relatedObjects',[]):yield from walk(c)

def main(apply):
 for name,template,diag in ENTRIES:
  old=json.loads((ROOT/(name+'-original-payload.txt')).read_text());new=json.loads((ROOT/(name+'-candidate.json')).read_text())
  assert len(list(walk(old['sourceObject'])))==len(list(walk(new['sourceObject'])))
  print(name+': propuesta local; '+str(len(list(walk(new['sourceObject']))))+' nodos.')
 if not apply:
  print('Sin --apply: no se ha consultado ni modificado ninguna org.');return
 org=call('preflight-org','query?q='+urllib.parse.quote('SELECT Id FROM Organization'))
 assert org['records'][0]['Id']==EXPECTED_ORG
 existing=call('preflight-diagnostic-names','query?q='+urllib.parse.quote("SELECT DataGraphApiName FROM DataGraph WHERE DataGraphApiName IN ('SOMA_Perfil_RT_QA_20261008','SOMA_Productos_RT_QA_20261008')"))
 assert existing['totalSize']==0,'Los nombres de prueba ya existen; se cancela sin modificar nada.'
 snapshots={}
 for name,template,diag in ENTRIES:
  original=call('snapshot-'+name,'tooling/sobjects/DataKitObjectTemplate/'+template)
  assert digest(original['EntityPayload'])==digest((ROOT/(name+'-original-payload.txt')).read_text()),'La plantilla ha cambiado desde la revisión; se cancela.'
  snapshots[template]=original['EntityPayload']
 (ROOT/'backup-antes-de-prueba.json').write_text(json.dumps(snapshots,ensure_ascii=False,indent=2))
 metadata=call('preflight-fields','ssot/metadata?dataspace=default')
 available={m['name'].lower():{f['name'] for f in m.get('fields',[])} for m in metadata['metadata']}
 for name,template,diag in ENTRIES:
  candidate=json.loads((ROOT/(name+'-candidate.json')).read_text())
  for node in walk(candidate['sourceObject']):
   if node['name'].startswith('ssot__'):
    assert all(f['sourceFieldName'] in available[node['name'].lower()] for f in node['fields']), 'Falta un campo de la propuesta; se cancela.'
 jobs=[];restoration={}
 try:
  for name,template,diag in ENTRIES:
   candidate=json.loads((ROOT/(name+'-candidate.json')).read_text())
   call('patch-temporal-'+name,'tooling/sobjects/DataKitObjectTemplate/'+template,'PATCH',{'EntityPayload':json.dumps(candidate,ensure_ascii=False)})
   job=call('deploy-diagnostic-'+name,'ssot/data-kits/SOMA_Graphs_v1?asyncMode=true&dataspace=default','POST',{'components':[{'type':'DataGraph','config':{'templateDevName':name,'name':diag,'label':diag+' (prueba temporal)','dataSpaceName':'default'}}]})['jobId']
   jobs.append({'graph':diag,'jobId':job});deadline=time.monotonic()+600
   while True:
    q="SELECT ComponentName,DeploymentStatus,DeploymentError FROM DataKitDeploymentLog WHERE JobIdentifier='"+job+"'"
    log=call('deployment-status-'+name,'query?q='+urllib.parse.quote(q))
    headers=[r for r in log['records'] if r['ComponentName'] is None]
    if headers and headers[0]['DeploymentStatus'] in ('Successful','Failed'):
     jobs[-1]['deploymentStatus']=headers[0]['DeploymentStatus'];jobs[-1]['deploymentError']=headers[0].get('DeploymentError');break
    if time.monotonic()>deadline:raise TimeoutError('No se ha confirmado el despliegue; se restaura antes de salir.')
    time.sleep(10)
 finally:
  for name,template,diag in ENTRIES:
   restored=False
   for attempt in range(3):
    try:
     call('restore-'+name+'-'+str(attempt),'tooling/sobjects/DataKitObjectTemplate/'+template,'PATCH',{'EntityPayload':snapshots[template]})
     check=call('verify-restore-'+name+'-'+str(attempt),'tooling/sobjects/DataKitObjectTemplate/'+template)
     restored=digest(check['EntityPayload'])==digest(snapshots[template])
     if restored:break
    except Exception:pass
   restoration[name]=restored
  (ROOT/'resultado-prueba-y-restauracion.json').write_text(json.dumps({'jobs':jobs,'restauracionVerificada':restoration},ensure_ascii=False,indent=2))
  if not all(restoration.values()):raise RuntimeError('RESTAURACIÓN NO CONFIRMADA. Aplicar backup-antes-de-prueba.json antes de continuar.')
 print('Las dos plantillas originales se han restaurado y sus hashes coinciden.')
 print('Los graphs QA son independientes; todavía se deben comprobar sus resultados y eliminarlos cuando terminen las pruebas.')

if __name__=='__main__':
 signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(SystemExit('Interrumpido; se intentará restaurar.')))
 parser=argparse.ArgumentParser();parser.add_argument('--apply',action='store_true');main(parser.parse_args().apply)
