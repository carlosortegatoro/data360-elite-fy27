# SOMA Casa HandsOn octubre 2026

Instalación: https://login.salesforce.com/packaging/installPackage.apexp?p0=04tgK000000QiYTQA0

Paquete unmanaged publicado, versión 1.1. Incluye tres kits: Identity (1 regla), Insights (6 cálculos) y Graphs (2 gráficos). Instalar el paquete añade templates; desplegar los templates crea los componentes operativos. Los datos no viajan dentro del paquete. La plantilla de identidad omite el DLO web de origen; añadir el DLO identity propio en la reconciliación tras desplegar la regla.

Seguir Guia_Prework_SOMA_2026.docx en la carpeta superior. Usar data space default y ruleset ID SOMA. Primero preparar modelos, datos, mapeos y relaciones; después desplegar identidad, ejecutar insights en orden y construir graphs. Si una fuente de reconciliación cambia de nombre, ajustar la regla al DLO de la org de destino; no forzar un nombre de la org de referencia.

## Materiales

- Datos: CSV corregidos extraídos de los DLO de referencia, 50 clientes, 120 pedidos, 6 productos. UTF-8, coma, fechas ISO UTC, teléfonos E164. No incluyen datos de navegación generados durante las pruebas.
- Web: esquema de 12 eventos exportado del conector vigente y sitemap 2.0.1 extraído del CDN publicado. Cargar ambos en el conector propio; copiar su URL CDN en las tres páginas del fork del sitio.
- Referencia: los 17 mapeos de campos y las estructuras completas de los dos graphs. Los sufijos del DLO web varían en cada org. Los filtros eventType del JSON son requisitos de configuración y deben aplicarse en la interfaz; el GET de mapeos no los devuelve. Estos JSON son referencias, no cuerpos de despliegue.
- SQL: definiciones originales y consultas de control. Los resultados calculados no viajan en el kit.
- DataKits: fuente Salesforce API 67.0, manifest y exportación mdapi del paquete. Sin credenciales. Para instalar usar el enlace del paquete; no desplegar ambas representaciones de la fuente a la vez.
- Validacion: resultados de los CSV y lista de control del piloto. Los recuentos globales de perfiles/eventos varían.

## Validación antes del evento

La publicación del paquete está confirmada por Salesforce (SUCCESS). La instalación y el despliegue completos en una org limpia todavía requieren un piloto. No distribuir a las 30 orgs hasta pasar la lista de control y confirmar que la regla de identidad resuelve los DLO de destino. El filtro de afinidad de la guía usa el calculated insight de compras; difiere del filtro de navegación encontrado en la org de referencia y se debe comprobar con Harold antes del evento.
