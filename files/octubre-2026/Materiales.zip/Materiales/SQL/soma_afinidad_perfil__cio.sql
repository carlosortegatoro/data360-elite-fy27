-- SQL original de la org de referencia, data space default.
SELECT UnifiedssotIndividualSoma__dlm.ssot__Id__c AS unified_id__c, soma_categoria_top__cio.categoria_top__c AS categoria_top__c, MAX(soma_categoria_top__cio.score_top__c) AS score_top__c
FROM UnifiedssotIndividualSoma__dlm
JOIN soma_categoria_top__cio ON UnifiedssotIndividualSoma__dlm.ssot__Id__c = soma_categoria_top__cio.unified_id__c
GROUP BY UnifiedssotIndividualSoma__dlm.ssot__Id__c, soma_categoria_top__cio.categoria_top__c;
