-- SQL original de la org de referencia, data space default.
SELECT soma_score_categoria__cio.unified_id__c AS unified_id__c, MAX(soma_score_categoria__cio.score__c) AS score_max__c
FROM soma_score_categoria__cio
GROUP BY soma_score_categoria__cio.unified_id__c;
