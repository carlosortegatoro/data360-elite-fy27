-- SQL original de la org de referencia, data space default.
SELECT ssot__SalesOrderProduct__dlm.ssot__ProductId__c AS producto_id__c, SUM(ssot__SalesOrderProduct__dlm.ssot__OrderedQuantity__c) AS popularidad__c, COUNT(ssot__SalesOrderProduct__dlm.ssot__Id__c) AS pedidos__c
FROM ssot__SalesOrderProduct__dlm
GROUP BY ssot__SalesOrderProduct__dlm.ssot__ProductId__c;
