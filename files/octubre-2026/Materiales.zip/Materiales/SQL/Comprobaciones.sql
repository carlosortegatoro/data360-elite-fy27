-- Query Editor de Data 360, data space default. Ejecutar cada SELECT por separado.
SELECT COUNT(*) AS filas FROM Clientes__dll;
SELECT COUNT(*) AS filas FROM Pedidos__dll;
SELECT COUNT(*) AS filas FROM Productos__dll;
SELECT ssot__PartyId__c, ssot__EmailAddress__c FROM ssot__ContactPointEmail__dlm WHERE ssot__EmailAddress__c = 'harold.emmerich@example.com';
SELECT UnifiedRecordId__c, SourceRecordId__c FROM UnifiedLinkssotIndividualSoma__dlm WHERE SourceRecordId__c = '3b7eee6d-da08-4f49-a75b-8da5564eaea0';
-- Sustituir ID_UNIFICADO_ORG por el UnifiedRecordId devuelto arriba.
SELECT unified_id__c, categoria_top__c, score_top__c FROM soma_afinidad_perfil__cio WHERE unified_id__c = 'ID_UNIFICADO_ORG';
SELECT producto_id__c, popularidad__c, pedidos__c FROM soma_popularidad_catalogo__cio ORDER BY popularidad__c DESC;
SELECT categoria_top__c, COUNT(*) AS perfiles FROM soma_afinidad_perfil__cio GROUP BY categoria_top__c;
