-- SQL original de la org de referencia, data space default.
SELECT soma_score_categoria__cio.unified_id__c AS unified_id__c, soma_score_categoria__cio.categoria__c AS categoria_top__c, MAX(soma_score_categoria__cio.score__c) AS score_top__c
FROM soma_score_categoria__cio
JOIN soma_score_max__cio ON soma_score_categoria__cio.unified_id__c = soma_score_max__cio.unified_id__c AND soma_score_categoria__cio.score__c = soma_score_max__cio.score_max__c
GROUP BY soma_score_categoria__cio.unified_id__c, soma_score_categoria__cio.categoria__c;
