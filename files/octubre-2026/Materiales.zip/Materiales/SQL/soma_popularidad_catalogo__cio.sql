-- SQL original de la org de referencia, data space default.
SELECT ssot__Product__dlm.ssot__Id__c AS producto_id__c, MAX(soma_popularidad_producto__cio.popularidad__c) AS popularidad__c, MAX(soma_popularidad_producto__cio.pedidos__c) AS pedidos__c
FROM ssot__Product__dlm
JOIN soma_popularidad_producto__cio ON ssot__Product__dlm.ssot__Id__c = soma_popularidad_producto__cio.producto_id__c
GROUP BY ssot__Product__dlm.ssot__Id__c;
